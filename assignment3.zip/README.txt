Created By Andrew Florial

Files: NaiveBayes.cpp, makefile, report.txt, readme.

Run Instructions

- open terminal

- type “make”

- execute ./NaiveBayes trainingfile testingfile 


Manual Run Instructions

- open terminal

- type “g++ -std=c++11 NaiveBayes.cpp”

- execute ./a.out trainingfile testingfile 
